from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.app.api.audit import router as audit_router
from backend.app.api.anchoring import router as anchoring_router  # optional, testnet anchoring
from backend.app.api.charter import router as charter_router
from backend.app.api.data_quality import router as data_quality_router
from backend.app.api.forecast import router as forecast_router
from backend.app.api.health import router as health_router
from backend.app.api.market import router as market_router
from backend.app.api.models import router as models_router
from backend.app.api.opportunity import router as opportunity_router
from backend.app.api.ports import router as ports_router
from backend.app.api.risk import router as risk_router
from backend.app.api.vessels import router as vessels_router

from backend.app.api.command_center import router as command_center_router
from backend.app.api.decisions import router as decisions_router
from backend.app.api.eligibility import router as eligibility_router
from backend.app.api.map import router as map_router
from backend.app.api.scenarios import router as scenarios_router
from backend.app.api.freight_database import router as freight_database_router

app = FastAPI(
    title="Freight Chartering Intelligence API",
    version="0.2.0",
    description="Local FastAPI boundary for forecasting, portfolio optimization, risk, port constraints, data quality, and CVC governance.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
app.include_router(forecast_router)
app.include_router(charter_router)
app.include_router(data_quality_router)
app.include_router(audit_router)
app.include_router(anchoring_router)
app.include_router(market_router)
app.include_router(models_router)
app.include_router(opportunity_router)
app.include_router(ports_router)
app.include_router(risk_router)
app.include_router(vessels_router)
app.include_router(command_center_router)
app.include_router(decisions_router)
app.include_router(eligibility_router)
app.include_router(map_router)
app.include_router(scenarios_router)
app.include_router(freight_database_router)
